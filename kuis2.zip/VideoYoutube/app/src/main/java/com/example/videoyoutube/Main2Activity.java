package com.example.videoyoutube;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

public class Main2Activity extends AppCompatActivity {
    Button button1,button2,button3;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        button1 = findViewById(R.id.button1);
        button2 = findViewById(R.id.button2);
        button3 = findViewById(R.id.button3);
    }
    public  void Tutorial1 (View view) {
        Intent intent = new Intent (this, MainActivity.class);
        startActivity(intent);
    }
    public  void Tutorial2 (View view) {
        Intent intent = new Intent (this, Main3Activity.class);
        startActivity(intent);
    }
    public  void Tutorial3 (View view) {
        Intent intent = new Intent (this, Main4Activity.class);
        startActivity(intent);
    }
}
