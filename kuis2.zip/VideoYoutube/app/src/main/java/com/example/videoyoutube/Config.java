package com.example.videoyoutube;

public class Config {
        //Google console APIs developer key
        //Replace this key with your's
    public static final String DEVELOPER_KEY = "AIzaSyBfurebMQgTiyX-njCZV0cEggSMaXenBb0";

    //Youtube Video id
    public static final String YOUTUBE_VIDEO_CODE = "83zZ5supNVE";
    public static final String YOUTUBE_VIDEO_CODE1 = "8V7rLJBTxo4";
    public static final String YOUTUBE_VIDEO_CODE2 = "sBoVGqiSzr4";
}
